package Pendrive.PageReplacement;

import java.util.*;

public class FIFO {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take user input for number of frames and pages
        System.out.print("Enter the number of frames: ");
        int numberOfFrames = scanner.nextInt();
        System.out.print("Enter the number of pages: ");
        int numberOfPages = scanner.nextInt();

        System.out.print("Enter the page reference string (space-separated): ");
        int[] pageReferenceString = new int[numberOfPages];
        for (int i = 0; i < numberOfPages; i++) {
            pageReferenceString[i] = scanner.nextInt();
        }

        // Initialize frames with -1 to represent empty frames
        int[] frames = new int[numberOfFrames];
        Arrays.fill(frames, -1);

        int pageFaults = 0;  // Count of page faults
        int currentIndex = 0;  // To track the current index for FIFO replacement

        // Process each page in the reference string
        for (int page : pageReferenceString) {
            boolean pageHit = false;

            // Check if the page is already in the frames (hit)
            for (int frame : frames) {
                if (frame == page) {
                    pageHit = true;
                    break;
                }
            }

            // If there is no page hit, replace a page (FIFO)
            if (!pageHit) {
                frames[currentIndex] = page;
                currentIndex = (currentIndex + 1) % numberOfFrames; // Circular update of the current index
                pageFaults++;  // Increment page faults
            }

            // Print the current state of the frames
            System.out.print("Frames: ");
            for (int frame : frames) {
                System.out.print(frame + " ");
            }
            System.out.println();
        }

        // Output the total number of page faults and the page fault ratio
        System.out.println("Total Page Faults: " + pageFaults);
        System.out.println("Page Fault Ratio: " + pageFaults + ":" + numberOfPages);

        // Close the scanner
        scanner.close();
    }
}
