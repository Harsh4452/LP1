package Pendrive.PageReplacement;

import java.util.*;

public class LeastRecentlyUsed{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of frames: ");
        int numberOfFrames = scanner.nextInt();
        
        System.out.print("Enter the number of pages: ");
        int numberOfPages = scanner.nextInt();
        
        System.out.print("Enter the page reference string (space-separated): ");
        int[] pageReferenceString = new int[numberOfPages];
        
        for (int i = 0; i < numberOfPages; i++) {
            pageReferenceString[i] = scanner.nextInt();
        }
        
        LinkedList<Integer> frames = new LinkedList<>();
        int pageFaults = 0;
        
        for (int page : pageReferenceString) {
            // If the page is not already in the frames
            if (!frames.contains(page)) {
                // If there's no space in frames, remove the least recently used page (front of the list)
                if (frames.size() >= numberOfFrames) {
                    frames.removeFirst();
                }
                frames.addLast(page);  // Add the new page to the end of the list
                pageFaults++;  // Increment the page fault count
            } else {
                // If the page is already in the frames, move it to the end (most recently used)
                frames.remove(frames.indexOf(page));
                frames.addLast(page);
            }

            // Print the current state of frames
            System.out.print("Frames: ");
            for (int frame : frames) {
                System.out.print(frame + " ");
            }
            System.out.println();
        }

        // Print the total page faults
        System.out.println("Total Page Faults: " + pageFaults);
        
        scanner.close();
    }
}

